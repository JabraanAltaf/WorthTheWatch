function searchWeather(searchTerm) {
    fetch(`http://www.omdbapi.com/?t=${searchTerm}&apikey=533c64dd`).then(result => {
        return result.json();
    }).then(result => {
        //  returnCode(result);
        init(result);
      //  returnCode(result);
    })
}

function setPositionForInfo() {
    let displayContainer = document.getElementById('displayContainer');
    let displayContainerH = displayContainer.clientHeight;
    let displayContainerW = displayContainer.clientWidth;

    displayContainer.style.left = `calc(50% - ${displayContainerW/1.8}px)`;
    displayContainer.style.top = `calc(50% - ${displayContainerH/2}px)`;
    displayContainer.style.visibility = 'visible';
}

function returnCode(resultsFromServer) {
    let title = resultsFromServer.Title;
    getISS(title);

}

function init(resultsFromServer) {
    
    let countryNameElement = document.getElementById('movieType');
    countryNameElement.innerHTML = resultsFromServer.Title + " " + 
         '(' + resultsFromServer.Year +')';
         
    let runtimeElem = document.getElementById('runtime');
        runtimeElem.innerHTML = "Runtime: " + resultsFromServer.Runtime;

    let genreElem = document.getElementById('genre');
        genreElem.innerHTML = "Genre: " + resultsFromServer.Genre;        

    let directorElem = document.getElementById('director');
        directorElem.innerHTML = "Director: " + resultsFromServer.Director;

    let imdbElement = document.getElementById('IMDB');

    imdbElement.innerHTML = "IMDB: " + resultsFromServer.imdbRating + " (" +
    resultsFromServer.imdbVotes + " votes)";
    

        
    let rotElement = document.getElementById('ROT');
    //let rotImg = document.getElementById('')
    let rotScore;
    if (typeof resultsFromServer.Ratings[1] != 'undefined') {
        rotElement.innerHTML = "ROT: " + resultsFromServer.Ratings[1].Value;
        let rotStr = resultsFromServer.Ratings[1].Value;
        rotScore= rotStr.slice(0,2);
    }
    else { 
        rotElement.innerHTML = "ROT: N/A";
    }
    
    let metaElement = document.getElementById('META');
    if (typeof resultsFromServer.Ratings[2] != 'undefined') {
        metaElement.innerHTML = "META: " + resultsFromServer.Ratings[2].Value;
    }
    else { 
        metaElement.innerHTML = "META: N/A";  
    }
    
    let imgElement = document.getElementById('movieImg');
    imgElement.src = resultsFromServer.Poster;

    let movInfo = document.getElementById('moviePlot');
    movInfo.innerHTML = "Plot: " + resultsFromServer.Plot;
 
   // console.log(rotStr.slice(0,2));

    //let yearElement= document.getElementById('year');
    //yearElement.innerHTML = resultsFromServer.Year;
    let worthItElement = document.getElementById('worth');
    if ( rotScore > 80) {
        var str = new String("WATCH IT!");
        worthItElement.innerHTML = str.fontcolor("green");
      // worthItElement.src = ;
    }
    else if(resultsFromServer.imdbRating > 6 && rotScore >= 60 && rotScore < 80){
        var str2 = new String("YOU MIGHT LIKE IT!");
       // str2.fontcolor("red");
        worthItElement.innerHTML = str2.fontcolor("yellow");
    }

    else if (resultsFromServer.imdbRating < 6){
        var str3 = new String("DON'T WATCH!");
       // str2.fontcolor("red");
        worthItElement.innerHTML = str3.fontcolor("red");
    }

    console.log(resultsFromServer);
 
}

//async function getISS(searchTerm) {

//    const api_url = `https://api.exchangeratesapi.io/latest?base=${searchTerm}`;
 //   const response = await fetch(api_url);
    //const resultsFromServer = await response.json();
    //   console.log(resultsFromServer);
    //  const country_name = resultsFromServer[0].name;
    //	const currencyCode = resultsFromServer[0].currencies[0].code;

    // const currencyName = resultsFromServer.rates.EUR;
    //	const currencyFlag = resultsFromServer[0].flag;
    //console.log(country_name);
    // console.log(currencyName);

    //const currenc

    //const gbpElement = document.getElementById('GBP');
    //gbpElement.innerHTML = `GBP: ${(resultsFromServer.rates.GBP)}`;

    //const eurElement = document.getElementById('EUR');
    //if (`${(resultsFromServer.rates.EUR)}` == 'undefined') {
     //   eurElement.innerHTML = "EUR: 1";
    //} else {
     //   eurElement.innerHTML = `EUR: ${(resultsFromServer.rates.EUR)}`;
    //}


    //const usdElement = document.getElementById('USD');
    //usdElement.innerHTML = `USD: ${(resultsFromServer.rates.USD)}`;
    //	console.log(currencyFlag);

    //let countryNameElement = document.getElementById('countryHeader');
    //countryNameElement.innerHTML = currencyName;

//}
function animate(){
    $('#displayContainer').addClass('.animate');
   // setTimeout(function(){$('#displayContainer').removeClass('animate');}, 10);
}


//getISS('GBP');
setPositionForInfo();
document.getElementById('searchBtn').addEventListener('click', (event) =>{
    let searchTerm = document.getElementById('searchInput').value;
     if(searchTerm){
         searchWeather(searchTerm);
     }
     
 })



//searchWeather('France');
//#movieInfo p {
  //  position: fixed;
   // left: 700px;
    //top: 150px;

  //  .container {

    //    padding-right: 15px;
      //  padding-left: 15px;
       // margin-left: -300px;
       // overflow-y: scroll;
  //  }   
//}